package bg.unwe;

/**
 *
 * @author Stoyan Angelow
 */
public interface Person {

    public String getName();

    public void setName(String name);

    public Country getCountry();

    public void setCountry(Country country);

}
